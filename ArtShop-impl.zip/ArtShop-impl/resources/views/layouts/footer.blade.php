<footer>
    <img src="/images/logo.png" alt="ArtShopLogo" class="float-right img-fluid">
</footer>
