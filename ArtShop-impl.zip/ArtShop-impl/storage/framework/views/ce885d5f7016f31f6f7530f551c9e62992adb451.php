

<?php $__env->startSection('content'); ?>

    <div class="row red">
        <?php if(empty($pictures)): ?>
            <div class="col-md-12 text-center">
                Nije pronadjena nijedna slika.
            </div>
        <?php else: ?>
            <?php ($pos = 0); ?>
            <?php ($flag = 0); ?>
            <?php $__currentLoopData = $pictures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $picture): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($picture->smer == "vertikalno"): ?>
                    <?php if($flag == 0): ?>
                        <?php if($pos == 2 && count($pictures) > $key + 1 && $pictures[$key + 1]->smer == 'horizontalno'): ?>
                            <div class="col-md-6 col-sm-12 pretraga">
                                <a href="/picture/<?php echo e($pictures[$key + 1]->id); ?>"><img src="<?php echo e($pictures[$key + 1]->path); ?>"></a>
                            </div>
                            <?php ($flag = 1); ?>
                        <?php endif; ?>
                        <div class="col-md-3 col-sm-6 pretraga">
                            <a href="/picture/<?php echo e($picture->id); ?>"><img src="<?php echo e($picture->path); ?>"></a>
                        </div>
                    <?php else: ?>
                        <?php ($flag = 0); ?>
                    <?php endif; ?>
                    <?php ($pos += 1); ?>
                    <?php ($pos %= 4); ?>
                <?php else: ?>
                    <?php if($flag == 0): ?>
                        <?php if($pos == 3 && count($pictures) > $key + 1 && $pictures[$key + 1]->smer == 'vertikalno'): ?>
                            <div class="col-md-3 col-sm-6 pretraga">
                                <a href="/picture/<?php echo e($pictures[$key + 1]->id); ?>"><img src="<?php echo e($pictures[$key + 1]->path); ?>"></a>
                            </div>
                            <?php ($flag = 1); ?>
                        <?php endif; ?>
                        <div class="col-md-6 col-sm-12 pretraga">
                            <a href="/picture/<?php echo e($picture->id); ?>"><img src="<?php echo e($picture->path); ?>"></a>
                        </div>
                    <?php else: ?>
                        <?php ($flag = 0); ?>
                    <?php endif; ?>
                    <?php ($pos += 2); ?>
                    <?php ($pos %= 4); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <footer>
        <img src="/images/logo.png" alt="ArtShopLogo" class="float-right img-fluid">
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/pretraga.blade.php ENDPATH**/ ?>