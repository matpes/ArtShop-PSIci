<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="/css/Matija.css">
    <script src="/js/Matija.js"></script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('header_form_2'); ?>
    <?php if(count($slike_u_korpi)>0): ?>

        <a href="kupac_forma">
            <button type="button" class="btn-dark gray_button"> Kupi slike</button>
        </a>
    <?php else: ?>
        <button disabled type="button" class="btn disabledButton gray_button"> Kupi slike</button>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-1">

        </div>
        <div class="col-10">
            <div class="row">
                <?php if(count($slike_u_korpi)>0): ?>
                    <?php for($i = 0; $i < count($slike_u_korpi); $i++): ?>
                        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 marginTop">
                            <div>
                                <a href="#" id="pictureModalWindow<?php echo e($i); ?>" onclick="prikazi('modalWindow<?php echo e($i); ?>')">
                                    <img src="<?php echo e($slike_u_korpi[$i]->path); ?>" alt="slika <?php echo e($i); ?>" class="image_cart">
                                </a>
                            </div>

                        </div>
                        <div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 marginTop">
                            <table class="table table-borderless">
                                <tr>
                                    <td rowspan="4" colspan="2" class="dark_background korpa_kratak_opis">
                                        Slika:
                                        <br>
                                        &emsp;
                                        <?php echo e($slike_u_korpi[$i]->naziv); ?>

                                        <br>
                                        Slikar:
                                        <br>
                                        &emsp;
                                        <?php echo e($slikari[$i]->username); ?>

                                        <div align="right">
                                            <a href="#" id="pictureDeleteModalWindow<?php echo e($i); ?>"
                                               onclick="prikazi('deleteModalWindow<?php echo e($i); ?>')">
                                                <img src="/images/design/trash.png" alt="">
                                            </a>
                                        </div>

                                    </td>
                                </tr>
                                <tr></tr>
                                <tr></tr>
                                <tr></tr>

                                <tr>
                                    <td>
                                        <input type="text" value="<?php echo e($slike_u_korpi[$i]->cena); ?>$" disabled
                                               class="form_input_text cenaPadding">
                                    </td>
                                    <td> &nbsp;</td>
                                </tr>
                            </table>
                        </div>
                    <?php endfor; ?>



                <?php else: ?>
                    <div class="offset-3 col-6">
                        <br><br><br>
                        <div class="emptyCart" style="padding: 50px">

                            Vasa korpa je prazna

                        </div>
                    </div>

                <?php endif; ?>
            </div>
            <br><br><br>
        </div>
        <div class="col-1">

        </div>
    </div>


    <?php for($i = 0; $i < count($slike_u_korpi); $i++): ?>

        <div id="modalWindow<?php echo e($i); ?>" class="modalWindow">

            <div class="row">


                <div class="col-6">
                    <img src="<?php echo e($slike_u_korpi[$i]->path); ?>" alt="slika<?php echo e($i); ?>" width="100%">
                </div>
                <div class="col-6">
                    <table class="table table-borderless">
                        <tr>
                            <td>
                                Slikar:
                            </td>
                            <td>
                                <?php echo e($slikari[$i]->username); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Stil:
                            </td>
                            <td>
                                <?php echo e($stilovi[$i]->naziv); ?>

                            </td>
                        </tr>
                        <tr>
                            <td>
                                Tema:
                            </td>
                            <td>
                                OVDE IDE TEMA
                            </td>
                        </tr>

                    </table>
                    <div style="overflow: auto">
                        <?php echo e($slike_u_korpi[$i]->opis); ?>

                    </div>

                </div>
                <div class="close" id="modalClose<?php echo e($i); ?>" onclick="sakrij('modalWindow<?php echo e($i); ?>')">+</div>
            </div>
        </div>

        <div id="deleteModalWindow<?php echo e($i); ?>" class="modalWindow text-center">
            <div>
                <h2>Upozorenje</h2>
                <h5>Da li sigurno zelite da izbacite sliku iz korpe</h5>
                <br><br><br>
                <form method="post" action="/korpa/<?php echo e($slike_u_korpi[$i]->id); ?>">
                    <input type="hidden" name="_method" value="DELETE">
                    <table class="table">
                        <tr>
                            <td>
                                <input type="submit" value="Potvrdi" name="potvrdi" class="btn-dark gray_button_100">
                                <?php echo e(csrf_field()); ?>

                            </td>
                            <td>

                                <input type="button" value="Odustani" class="btn-dark gray_button_100"
                                       id="modalDeleteClose<?php echo e($i); ?>" onclick="sakrij('deleteModalWindow<?php echo e($i); ?>')">

                            </td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    <?php endfor; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views//korpa.blade.php ENDPATH**/ ?>