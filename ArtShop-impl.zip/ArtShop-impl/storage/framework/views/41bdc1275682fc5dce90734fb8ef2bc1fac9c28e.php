<?php $__env->startSection('cenaIDugmici'); ?>

    <div class="opisSlike pozicijaDugmadiSlika">
        <form action="<?php echo e($picture->id); ?>/edit" method="get" class="form-group">

            <label for="mojaCena" class="cenaText">Moja cena:</label>
            <input type="text" name="mojaCena" id="mojaCena" class="form-control form_input_text cenaInputText">
            <label for="mojaCena" class="cenaText">$</label>
            <input type="hidden" name="id" value="<?php echo e($picture->id); ?>">
            <?php echo e(csrf_field()); ?>

            <?php if($bought): ?>
                <input disabled type="submit" name="ponudi" value="PONUDI"
                       class="form-control  kuplenoDugmic">
            <?php else: ?>
                <input type="submit" name="ponudi" value="PONUDI"
                       class="form-control dugmiciSlika btn-dark">
            <?php endif; ?>
        </form>
        <form action="">
            <input type="button" name="komentari" value="KOMENTARI" class="form-control dugmiciSlika btn-dark">
            <?php echo e(csrf_field()); ?>

        </form>
        <form action="/subscribe" method="post">
            <input type="hidden" name="slikar" value="<?php echo e($picture->user_id); ?>">
            <input type="hidden" name="picture" value="<?php echo e($picture->id); ?>">
            <?php echo e(csrf_field()); ?>

            <?php if($subscribed): ?>
                <input disabled type="submit" name="prijava" value="SUBSCRIBE" class="form-control kuplenoDugmic">
            <?php else: ?>
                <input type="submit" name="prijava" value="SUBSCRIBE" class="form-control dugmiciSlika btn-dark">
            <?php endif; ?>
            <span class="cenaText">Aukcija traje još:</span>
            <label for="" class="cenaLable" id="trajanje"></label>
        </form>



    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pictureBase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views//pictureClosed.blade.php ENDPATH**/ ?>