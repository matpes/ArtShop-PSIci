

<?php $__env->startSection('head'); ?>
    <script src="http://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/Matija.css">
    <script src="/js/Matija.js"></script>
    <script src="/js/Zvezdice.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header_form'); ?>

    <a href="/profileInfo" >
        <img src="<?php echo e($path); ?>" alt="AAAA" class="img-fluid float-right" style="padding-left: 20px">
    </a>
    <a href="/korpa">
        <img src="/images/design/cart.png" alt="BBBB" class="img-fluid float-right">
    </a>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-1">

        </div>
        <div class="col-10">
            <?php if(count($slikeZaOcenu)>0): ?>
            <?php for($i = 0; $i < count($slikeZaOcenu); $i++): ?>

                <div class="row">
                    <div class="col-sm-12 col-md-3">
                        <img src="<?php echo e($slikeZaOcenu[$i]->path); ?>" alt="" class="img-fluid" width="100%">
                    </div>
                    <div class="col-sm-12 col-md-9">

                        <div style="color:white;">
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>0"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>1"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>2"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>3"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>4"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>5"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>6"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>7"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>8"></i>
                            <i class="fa fa-star fa-2x" data-index="<?php echo e($i); ?>9"></i>
                            <br>
                        </div>
                        <br>
                        <div class="dark_background korpa_kratak_opis">
                            &emsp;Slika: <br>
                            &emsp;&emsp; <?php echo e($slikeZaOcenu[$i]->naziv); ?> <br>
                            &emsp;Slikar: <br>
                            &emsp;&emsp; <?php echo e($slikeZaOcenu[$i]->autor); ?> <br>
                        </div>
                    </div>
                </div>
                <br>
                <br>
            <?php endfor; ?>

            <form action="zaOcenu" method="post">
                <input type="submit" value="Zavrsi" class="btn-dark gray_button zavrsiButton">
                <?php echo e(csrf_field()); ?>

                <?php for($i = 0; $i < count($slikeZaOcenu); $i++): ?>
                    <input type="hidden" name="pic<?php echo e($i); ?>" value="<?php echo e($slikeZaOcenu[$i]->id); ?>">
                    <input type="hidden" name="<?php echo e($slikeZaOcenu[$i]->id); ?>" id="pic<?php echo e($i); ?>" value="0">
                <?php endfor; ?>
                <input type="hidden" name="numberOfPics" value="<?php echo e(count($slikeZaOcenu)); ?>">
            </form>
            <?php else: ?>
                <div class="row">
                    <div class="offset-3 col-6">
                        <div class="emptyCart" style="padding: 150px">
                            Nemate slika za ocenjivanje
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <br><br><br><br><br>
        </div>
        <div class="col-1">

        </div>
    </div>







<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views//ocene.blade.php ENDPATH**/ ?>