


<?php $__env->startSection('head'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.5/jquery.min.js"></script>
    <script>
        var cnt = 0;
        function go(n,br) {
            cnt = cnt + n;
            if(cnt >= br){
                cnt = 0;
            } else if(cnt < 0){
                cnt = br - 1;
            }
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $.ajax({
                type:'POST',
                url:'/profile/user_slikar',
                data:{cnt:cnt, br:br},
                success:function(data) {
                    $("#pic").attr("src",data.path);
                    $("#pic").attr("alt",data.naziv);;
                    $("#naziv").html(data.naziv);
                    $("#stil").html(data.stil);
                    $("#tema").html(data.tema);
                    $("#nacin").html(data.nacin);
                    $("#opis").html(data.opis);
                    $("#cena").html(data.cena);
                    $("#num").html(data.num);
                }
            });
        }
    </script>
    <link rel="stylesheet" type="text/css" href="/css/Sanja.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <?php if(is_null($novo)): ?>
                <div class="col-md-12 justify-content-center" >
                    <div class="alert alert-success mt-5 text-center" role="alert">
                        <?php echo e(__('Nemate slika! Kada objavite sliku ovde će se prikazati.')); ?>

                    </div>
                    <br> <br> <br>
                    
                    <form method="GET" action="<?php echo e(route('profile.user_new', ['id'=>$user->id])); ?>" class="offset-md-5">
                        <button type="submit" class="btn btn-warning offset-md-5">
                            <?php echo e(__('Nazad na početnu')); ?>

                        </button>
                    </form>
                </div>
            <?php else: ?>
            
            <div class="col-md-6 justify-content-center">
                <div class="gray_title" id="naziv"> <?php echo e(__($novo->naziv)); ?> </div>
                <br>
                <div class="slideshow-container mt-2">
                    <div class="myPics" style="display: block;">
                        <div class="numbertext" id="num"><?php echo $cnt + 1;?> / <?php echo $br;?></div>
                        <img src="<?php echo $novo->path; ?>" class="my-slide-image"
                             id = "pic" alt="<?php echo $novo->naziv; ?>">
                    </div>
                </div>
            </div>
            
            <div class="col-md-6 justify-content-center">
                <div class="title-opis"> Opis: </div>
                <br>
                <div id="opis"> <?php echo $novo->opis; ?></div>
                <br>
                <div class="custom-control-inline">
                    <label class="text-md-left" for="cena"> Cena: &nbsp; </label>
                    <div class="text-md-left" id="cena"><?php echo $novo->cena;?></div> <div>&nbsp; RSD</div>
                </div>
                <br> <br>
                <button type="button" class="btn-dark gray_button mb-5" onclick="go(-1, <?php echo $br;?>)"
                        style="width: fit-content;">
                    <?php echo e(__('Nazad')); ?>

                </button>
                <button type="button" class="btn-dark gray_button mb-5" onclick="go(1, <?php echo $br;?>)"
                        style="width: fit-content;">
                    <?php echo e(__('Napred')); ?>

                </button>
                <br>
                <div>
                    <div class="custom-control-inline">
                        <label class="text-md-left" for="nacin">Način prodaje: &nbsp; </label>
                        <div class="text-md-left" id="nacin"><?php if($novo->aukcijaFlag): ?> aukcija <?php else: ?> prvom kupcu <?php endif; ?></div>
                    </div>
                    <br>
                    <div class="custom-control-inline">
                        <label class="text-md-left" for="stil">Stil: &nbsp; </label>
                        <div class="text-md-left" id="stil"><?php echo $stil->naziv; ?></div>
                    </div>
                    <br>
                    <div class="custom-control-inline">
                        <label class="text-md-left" for="tema">Tema: &nbsp;</label>
                        <div class="text-md-left" id="tema">
                            <?php $__currentLoopData = $tema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $t->tema. ' &emsp; '; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <br>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php if(is_null($novo)): ?> <footer> <?php endif; ?>
        <img src="/images/logo.png" alt="ArtShopLogo" class="float-right img-fluid">
        <?php if(is_null($novo)): ?></footer> <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/profile/user_slikar.blade.php ENDPATH**/ ?>