


<?php $__env->startSection('cenaIDugmici'); ?>

    <div class="opisSlike pozicijaDugmadiSlika">


        <form action="<?php echo e($picture->id); ?>/edit" method="get" class="form-group">
            
            <label for="mojaCena" class="cenaText">Cena:</label>
            <label for="" class="cenaLable"><?php echo e($picture->cena); ?></label>
            <label for="mojaCena" class="cenaText">$</label>
            <?php echo e(csrf_field()); ?>

            <?php if($bought): ?>

                <input disabled type="submit" name="ubaciUKorpu" value="UBACI U KORPU"
                       class="form-control  kuplenoDugmic">
            <?php else: ?>
                <input type="submit" name="ubaciUKorpu" value="UBACI U KORPU"
                       class="form-control dugmiciSlika btn-dark">
            <?php endif; ?>

        </form>

        <form action="/comments" method="get">
            <input type="hidden" name="picture_id" value="<?php echo e($picture->id); ?>">
            <input type="submit" name="komentari" value="KOMENTARI" class="form-control dugmiciSlika btn-dark">
        </form>
        <form action="/subscribe" method="post">
            <input type="hidden" name="slikar" value="<?php echo e($picture->user_id); ?>">
            <input type="hidden" name="picture" value="<?php echo e($picture->id); ?>">
            <?php echo e(csrf_field()); ?>

            <?php if($subscribed): ?>
                <input disabled type="submit" name="prijava" value="SUBSCRIBE" class="form-control kuplenoDugmic">
            <?php else: ?>
                <input type="submit" name="prijava" value="SUBSCRIBE" class="form-control dugmiciSlika btn-dark">
            <?php endif; ?>
        </form>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('pictureBase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views//pictureSimple.blade.php ENDPATH**/ ?>