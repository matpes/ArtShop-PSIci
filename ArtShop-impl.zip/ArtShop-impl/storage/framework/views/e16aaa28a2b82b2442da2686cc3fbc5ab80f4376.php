

<?php $__env->startSection('head'); ?>
    <script src="http://code.jquery.com/jquery-3.4.0.min.js" integrity="sha256-BJeo0qm959uMBGb65z40ejJYGSgR7REI4+CW1fNKwOg=" crossorigin="anonymous"></script>

    <script type="text/javascript">
        var end = new Date('<?php echo e($endTime); ?>');
    </script>
    <link rel="stylesheet" href="/css/Matija.css">
    <script src="/js/Matija.js"></script>
    <script src="/js/timer.js"></script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>


    <div class="row">
        <div class="col-1">

        </div>
        <div class="col-10">
            <div class="row">
                <div class="col-xs-12 col-md-4">
                    <div class="nazivSlike">
                        <?php echo e($picture->naziv); ?>

                    </div>
                    <img src="<?php echo e($picture->path); ?>" alt="" class="img-fluid" width="100%">
                    <div>
                        <table class="table table-borderless">
                            <tr>
                                <td class="detaljiSlike">
                                    Slikar:
                                </td>
                                <td class="detaljiSlike">
                                    <?php echo e($picture->autor); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="detaljiSlike">
                                    Stil:
                                </td>
                                <td class="detaljiSlike">
                                    <?php echo e($stil->naziv); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="detaljiSlike">
                                    Tema:
                                </td>
                                <td class="detaljiSlike">
                                    <?php $__currentLoopData = $teme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e('#'.$tema->tema); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="col-xs-12 col-md-6">
                    <br><br><br>
                    <div class="opisSlike">
                        <?php echo e($picture->opis); ?>

                    </div>
                    <br><br><br>
                    <?php echo $__env->yieldContent('cenaIDugmici'); ?>
                </div>
            </div>
        </div>
        <div class="col-1">

        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/pictureBase.blade.php ENDPATH**/ ?>