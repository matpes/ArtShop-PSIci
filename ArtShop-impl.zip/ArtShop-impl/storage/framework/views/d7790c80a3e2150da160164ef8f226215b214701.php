










<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-1">

        </div>
        <div class="col-10">
            <form action="/slika" method="post" class="form-group">
                <div class="row">


                    <div class="col-sm-5 col-xs-12 padding_form_picture">
                        <img src="<?php if(isset($picture->path)): ?><?php echo e($picture->path); ?> <?php else: ?> <?php echo e('\images\design\images-empty.png'); ?> <?php endif; ?>" id="uploaded_image" width="100%">
                        <div class="bottom">
                            <label for="file_path" class="load_file">
                                Ucitaj sliku
                            </label>
                            <?php ($user = \App\User::find(Auth::id())); ?>
                            <input type="hidden" id="path" name="path" value="<?php if(isset($picture->path)): ?><?php echo e($picture->path); ?> <?php endif; ?>">
                            <input id="file_path" type="file" name="file_path" class="form-control form_input_text" style="width: 100%" oninput="document.getElementById('uploaded_image').setAttribute('src','\\images\\<?php echo e($user->username); ?>' + value.substr(value.lastIndexOf('\\'))); document.getElementById('path').value='\\images\\<?php echo e($user->username); ?>' + value.substr(value.lastIndexOf('\\'));"/>
                            <small><?php if(isset($error['path'])): ?><?php echo e($error['path']); ?> <?php endif; ?></small>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-7 paddingTopAndBot text-center">
                        <div class="row padding-top">
                            <div class="col-sm-5 text-right">
                                <label for="naziv" class="form_label_text">
                                    Naziv:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <input type="text" name="naziv" id="naziv" class="form-control form_input_text" value="<?php if(isset($picture->naziv)): ?><?php echo e($picture->naziv); ?> <?php endif; ?>">
                                <small><?php if(isset($error['naziv'])): ?><?php echo e($error['naziv']); ?> <?php endif; ?></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="autor" class="form_label_text">
                                    Autor:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <input type="text" name="autor" id="autor" class="form-control form_input_text" value="<?php if(isset($picture->autor)): ?><?php echo e($picture->autor); ?> <?php endif; ?>">
                                <small><?php if(isset($error['autor'])): ?><?php echo e($error['autor']); ?> <?php endif; ?></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="stil" class="form_label_text">
                                    Stil:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <select name="stil_id" id="stil" class="form-control form_input_text">
                                    <option value="renesansa" <?php if(isset($picture->stil_id) && $picture->stil_id == 1): ?> selected = "selected" <?php endif; ?>>Renesansa</option>
                                    <option value="barok" <?php if(isset($picture->stil_id) && $picture->stil_id == 2): ?> selected = "selected" <?php endif; ?>>Barok</option>
                                    <option value="klasicizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 3): ?> selected = "selected" <?php endif; ?>>Klasicizam</option>
                                    <option value="neoklasicizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 4): ?> selected = "selected" <?php endif; ?>>Neoklasicizam</option>
                                    <option value="romantizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 5): ?> selected = "selected" <?php endif; ?>>Romantizam</option>
                                    <option value="impresionizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 6): ?> selected = "selected" <?php endif; ?>>Impresionizam</option>
                                    <option value="simbolizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 7): ?> selected = "selected" <?php endif; ?>>Simbolizam</option>
                                    <option value="ekspresionizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 8): ?> selected = "selected" <?php endif; ?>>Ekspresionizam</option>
                                    <option value="kubizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 9): ?> selected = "selected" <?php endif; ?>>Kubizam</option>
                                    <option value="futurizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 10): ?> selected = "selected" <?php endif; ?>>Futurizam</option>
                                    <option value="dadaizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 11): ?> selected = "selected" <?php endif; ?>>Dadaizam</option>
                                    <option value="nadrealizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 12): ?> selected = "selected" <?php endif; ?>>Nadrealizam</option>
                                    <option value="popart" <?php if(isset($picture->stil_id) && $picture->stil_id == 13): ?> selected = "selected" <?php endif; ?>>Pop art</option>
                                    <option value="postmodernizam" <?php if(isset($picture->stil_id) && $picture->stil_id == 14): ?> selected = "selected" <?php endif; ?>>Postmodernizam</option>
                                    <option value="savremenaUmetnost" <?php if(isset($picture->stil_id) && $picture->stil_id == 15): ?> selected = "selected" <?php endif; ?>>Savremena umetnost</option>
                                </select>
                                <small></small>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="teme" class="form_label_text">
                                    Teme:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <input type="text" name="teme" id="teme" class="form-control form_input_text" value="<?php if(isset($teme)): ?><?php echo e($teme); ?> <?php endif; ?>" placeholder="npr. priroda, portret, ...">
                                <small></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="opis" class="form_label_text">
                                    Opis:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <textarea name="opis" id="opis" class="form-control form_input_text"> <?php if(isset($picture->opis)): ?><?php echo e($picture->opis); ?> <?php endif; ?> </textarea>
                                <small><?php if(isset($error['opis'])): ?><?php echo e($error['opis']); ?> <?php endif; ?></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="smer" class="form_label_text">
                                    Smer:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <select name="smer" id="smer" class="form-control form_input_text">
                                    <option value="horizontalno"<?php if(isset($picture->smer) && $picture->smer == 'horizontalno'): ?> selected = "selected" <?php endif; ?>>Horizontalno</option>
                                    <option value="vertikalno" <?php if(isset($picture->smer) && $picture->smer == 'vertikalno'): ?> selected = "selected" <?php endif; ?>>Vertikalno</option>
                                </select>
                                <small></small>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="radio" name="aukcijaFlag" id="javnaAukcija" value="javnaAukcija" class="form_checkbox" <?php if(isset($picture->aukcijaFlag) && $picture->aukcijaFlag == 1): ?> checked <?php endif; ?>>
                                <?php echo e(csrf_field()); ?>

                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="javnaAukcija" class="form_label_text">
                                    Javna aukcija
                                </label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="radio" name="aukcijaFlag" id="tajnaAukcija" value="tajnaAukcija" class="form_checkbox" <?php if(isset($picture->aukcijaFlag) && $picture->aukcijaFlag == 2): ?> checked <?php endif; ?>>
                                <?php echo e(csrf_field()); ?>

                            </div>
                            <div class="col-sm-6 text-left">
                                <label for="tajnaAukcija" class="form_label_text">
                                    Tajna aukcija
                                </label>
                            </div>
                        </div>
                        <div class="row padding-top">
                            <div class="col-sm-5 text-right">
                                <label for="danIstekaAukcije" class="form_label_text">
                                    Traje do:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <input type="date" name="danIstekaAukcije" id="danIstekaAukcije" class="form-control form_input_text" value=<?php if(isset($picture->danIstekaAukcije)): ?> <?php echo e(date($picture->danIstekaAukcije->format('Y-m-d'))); ?> <?php endif; ?>>
                                <?php if(isset($picture->danIstekaAukcije)): ?> <?php echo e(date($picture->danIstekaAukcije->format('Y-m-d'))); ?> <?php endif; ?>
                                <small><?php if(isset($error['danIstekaAukcije'])): ?><?php echo e($error['danIstekaAukcije']); ?> <?php endif; ?></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-5 text-right">
                                <label for="cena" class="form_label_text">
                                    Cena:
                                </label>
                            </div>
                            <div class="col-sm-7">
                                <input type="text" name="cena" id="cena" class="form-control form_input_text" value="<?php if(isset($picture->cena)): ?><?php echo e($picture->cena); ?> <?php endif; ?>">
                                <small><?php if(isset($error['cena'])): ?><?php echo e($error['cena']); ?> <?php endif; ?></small>
                                <?php echo e(csrf_field()); ?>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
                                <button type="submit" name="potvrdi" class="btn-success form-control form_gray_button">
                                    Potvrdi
                                </button>
                                <input type="hidden" value="<?php echo e(csrf_token()); ?>">
                            </div>
                            <div class="col-sm-6">
                                <button type="button" class="btn-success form-control form_gray_button">
                                    Odustani
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
            <br><br><br>
        </div>
        <div class="col-1">

        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('footer'); ?>

    <footer>
        <img src="/images/logo.png" alt="ArtShopLogo" class="float-right img-fluid">
    </footer>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/slika_form.blade.php ENDPATH**/ ?>