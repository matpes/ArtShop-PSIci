

<?php $__env->startSection('head'); ?>
    <script src="/js/Sanja.js"></script>
    <link rel="stylesheet" type="text/css" href="/css/Sanja.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container mt-0" onload="showSlides(0)">
    <div class="row justify-content-center">
        <div class="justify-content-center">
            <div class="box"> Najnovije </div>
            <br>
        </div>
    </div>
    <div class="row justify-content-center">
        <div class="col-md-12 justify-content-center mb-3 mt-4">
            <?php if(sizeof($novo) == 0): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(__('Nema novih slika!')); ?>

                </div>
            <?php else: ?>
                <div class="slideshow-container">
                    <?php for($i=0;$i<sizeof($novo);$i++): ?>
                        <div class="mySlides">
                            <div class="numbertext"><?php $p = ($i + 1) . ' / ' . sizeof($novo); echo $p; ?></div>
                            <img src="<?php echo $novo[$i]->path; ?>" class="slide-image"
                                 
                                alt="<?php echo $novo[$i]->opis; ?>">
                            <div class="text"><?php echo e(__($novo[$i]->naziv)); ?></div>
                        </div>
                    <?php endfor; ?>
                </div>
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <img src="/images/logo.png" alt="ArtShopLogo" class="float-right img-fluid">
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/layouts/base.blade.php ENDPATH**/ ?>