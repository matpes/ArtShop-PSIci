<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<h1>Pobedili ste na aukciji za sliku <?php echo e($picture->naziv); ?></h1>
<p>
    CESTITAMO!
    Pobedili ste na aukciji za sliku.
    Vasa ponuda je iznosila <?php echo e($picture->cena); ?>.
    Pogledajte sliku na: artshop.test/picture/<?php echo e($picture->id); ?>

</p>

</body>
</html>
<?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/mails/pictureWon.blade.php ENDPATH**/ ?>