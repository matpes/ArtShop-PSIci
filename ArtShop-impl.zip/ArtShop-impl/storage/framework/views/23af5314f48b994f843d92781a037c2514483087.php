





<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>ArtShop</title>
    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('images/logo.png')); ?>" type="image/gif" sizes="16x16">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
            integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
            integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
            crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"
            integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
            crossorigin="anonymous"></script>

    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <script type="javascript">
        var modal = document.getElementById("myModal");

        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on the button, open the modal
        btn.onclick = function () {
            modal.style.display = "block";
        }

        // When the user clicks on <span> (x), close the modal
        span.onclick = function () {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function (event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
    </script>
</head>
<body class="body">
<div class="container-fluid">
    <div class="row justify-content-center noPadding">
        
        <div class="col-md-4 mb-0 ml-0 text-md-left noPadding">
            
            <div class="col-md-12 text-md-left mt-3">Profilna slika: &emsp;
                <img id='profilna' class = "img-fluid " style="" width="140px" height="140px" alt="profilna_slika"
                     src= <?php if(is_null($user->picture_path)){ echo'\images/avatar.png';}
                else {$path = '\images\users\\'.$user->picture_path; echo $path; } ?>>
            </div>
            <br>
            
            <div class="col-md-12 text-md-left">E-mail: &emsp; <?php echo e(__($user->email)); ?></div>
            <br>
            
            <div class="col-md-12 text-md-left">Korisničko ime: &emsp; <?php echo e(__($user->username)); ?></div>
            <br>
            
            <form method="GET" action="<?php echo e(route('password.reset', ['token'=>csrf_token()])); ?>">
                <button type="submit" class="btn-warning">
                    <?php echo e(__('Promeni lozinku')); ?>

                </button>
            </form>
            <br>
            
            <div class="col-md-12 text-md-left">Tip naloga: &emsp;
                <?php if($user->isSlikar){ echo'SLIKAR';}
                else if($user->isAdmin){echo 'ADMIN';}
                else {echo 'KUPAC';}?>
            </div>
            <?php if($user->isSlikar): ?>
                
                <div class="text-md-left">Prosečna ocena: &emsp;
                    <?php if($slikar->sumaOcena == 0){
                        $ocena = "Nemate još nijednu ocenu/sliku";
                    } else{
                        $ocena = $slikar->sumaOcena / $slikar->brOcenjenihSlika;
                    }
                    echo $ocena; ?>
                </div>
                <br>
                
                <div class="text-md-left">Broj ocena: &emsp;
                    <?php echo $slikar->brOcenjenihSlika; ?>
                </div>
            <?php endif; ?>
            <br>
        </div>
        
        <div class="col-md-3 mb-0" style="vertical-align: middle;">
            <br>
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <br>
                
                <div class="col-md-12 text-md-left">Lozinka: &nbsp;
                    <form method="GET" action="/password/reset/">
                        <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>">
                    </form>
                </div>
            <?php else: ?>
                <br> <br>
            <?php endif; ?>
            <form method="GET" action="<?php echo e(route('profile.picture', ['id'=> Auth::user()->id])); ?>">
                <button type="submit" class="btn btn-warning">
                    <?php echo e(__('Promeni profilnu sliku')); ?>

                </button>
            </form>
            <br> <br> <br> <br> <br>
            <?php if($user->isSlikar): ?>
            <div class="row justify-content-center">
                <div class="col-md-12">
                    
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn-warning">
                            <?php echo e(__('Izloguj se')); ?>

                        </button>
                    </form>
                </div>
                <br>
                
            </div>


            <br> <br> <br>
            <?php else: ?>
                <br> <br> <br>
            <?php endif; ?>
            <div class="row justify-content-center">
                <div class="col-md-12 float-md-left">
                    
                    <button type="button" id="myBtn" class="btn btn-warning" data-toggle="modal" data-target="#myModal">
                        Ugasi nalog</button>
                </div>
            </div>
        </div>
        
        <div class="col-md-3 mb-0">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <br> <br> <br>
                    <?php if(Auth::check()): ?>
                        <?php if($user->isSlikar): ?>
                            
                            <form method="GET" action="<?php echo e(route('profile.user_slikar', ['id'=>$user->id])); ?>">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Moj profil')); ?>

                                </button>
                            </form>
                            <br> <br>
                            
                            <form method="GET" action="<?php echo e(route('profile.user', ['id'=>$user->id])); ?>">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Objavi sliku')); ?>

                                </button>
                            </form>
                            <br> <br>
                            
                            <form method="GET" action="<?php echo e(route('profile.user', ['id'=>$user->id])); ?>">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Objavi izložbu')); ?>

                                </button>
                            </form>
                            <br> <br>
                            
                            <form method="GET" action="<?php echo e(route('profile.user_new', ['id'=>$user->id])); ?>">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Povratak na početnu')); ?>

                                </button>
                            </form>
                            <br> <br>
                        <?php elseif($user->isAdmin): ?>
                            <div class="col-md-8 offset-md-4"> admin </div>

                        <?php else: ?>
                            <br>
                            
                            <form method="GET" action="<?php echo e(route('profile.user_new', ['id'=>$user->id])); ?>">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Povratak na početnu')); ?>

                                </button>
                            </form>
                            <br>
                            <form method="GET" action="/zaOcenu">
                                <button type="submit" class="btn btn-warning" >
                                    <?php echo e(__('Oceni slike')); ?>

                                </button>
                            </form>
                            <br>
                            
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn-warning">
                                    <?php echo e(__('Izloguj se')); ?>

                                </button>
                            </form>
                            <br>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<div class="container-fluid">
    <div class="modal" id="myModal" style="margin-top:15%;color:black;">
        <div class="modal-dialog">
            <div class="modal-content" style="background-color:rgb(64,64,64);color:#7FF000">
                <div class="modal-header">
                    <h5 style="font-size:20px">Uklanjanje naloga</h5>
                </div>
                <div class="modal-body">
                    <p>Da li ste sigurni da želite da uklonite svoj nalog?</p>
                </div>
                <div class="modal-footer">
                    <form method="POST" action="<?php echo e(route('removeAccount',['id'=>Auth::user()->id])); ?>">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-warning">Potvrdi</button>
                        <button type="button" class="btn btn-warning" data-dismiss="modal">Odustani</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH E:\wamp64\www\New folder\ArtShop-PSIci\ArtShop-impl\resources\views/profile/info.blade.php ENDPATH**/ ?>